import React, { useState } from "react";
import "./CarroselADM.css";

const CarroselADM = () => {
  const images = [
    {
      src: "https://static.vecteezy.com/system/resources/previews/017/395/377/non_2x/google-meets-icon-free-png.png",
      alt: "Google Meet",
    },
    {
      src: "https://cdn-icons-png.flaticon.com/512/2965/2965358.png",
      alt: "Google Docs",
    },
    {
      src: "https://cdn-icons-png.flaticon.com/512/732/732221.png",
      alt: "Google Calendar",
    },
    {
      src: "https://upload.wikimedia.org/wikipedia/commons/4/4f/Microsoft_Teams_2020_Logo.svg",
      alt: "Microsoft Teams",
    },
    {
      src: "https://cdn-icons-png.flaticon.com/512/732/732229.png",
      alt: "Microsoft Outlook",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="carouselADM-container">
      <button className="carouselADM-btn left" onClick={prevSlide}>
        ❮
      </button>

      <div className="carouselADM-slide">
        <img
          src={images[currentIndex].src}
          alt={images[currentIndex].alt}
          className="carouselADM-img"
        />
        <p className="carouselADM-caption">{images[currentIndex].alt}</p>
      </div>

      <button className="carouselADM-btn right" onClick={nextSlide}>
        ❯
      </button>
    </div>
  );
};

export default CarroselADM;
